# from setuptools import setup
from distutils.core import setup
setup(name='pymfg',
      version='1.2',
      description='Python Distribution ',
      author='Khang Van',
      author_email='vanthaikhang@gmail.com',
      packages=['pymfg'],
      zip_safe = False

     )