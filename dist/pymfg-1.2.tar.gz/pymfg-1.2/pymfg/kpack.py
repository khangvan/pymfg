class KPACK():
    """ this is prototype modle to deplay six sigmat
    
    """
    def __init__(self,name):
        self.name=name
    def do_something(self):
        print(self.name)